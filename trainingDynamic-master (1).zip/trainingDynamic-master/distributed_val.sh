#!/bin/bash
NUM_PROC=$1
shift
python3  validate.py "$@"

